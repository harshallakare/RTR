#include<stdio.h>

int main(void)
{
	//varibale declarations 
	int a = 5; 
	int b = 10; 

	printf("Harshal Lakare");
	//code 
	printf("\n\n");
	printf("A = %d\n",a);
	printf("A = %d\n", a++);
	printf("A = %d\n", a);
	printf("A = %d\n\n", ++a);

	printf("B = %d\n", b);
	printf("B = %d\n", b--);
	printf("B = %d\n", b);
	printf("B = %d\n\n", --b);
	
	return(0);
	}
