#include<stdio.h>
int main(void)
{
	//code
	printf("HBL - Hello, world !!!\n");
	return(0);
	//test
}